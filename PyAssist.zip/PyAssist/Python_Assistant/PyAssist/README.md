# PyDa

PyDa is the Python Digital Assistant. It is designed to do various tasks on a linux computer.

It is a GUI interface that encorporates thee Speech_Recognition api as well as others such as the webbrowser,
and goslate apis. More apis are used but come ready with ubuntu and or python itself.

You can download different mods to add to the main.py. These mods will usually have dependencies

To find out all of PyDa's commands and tricks, go to help.txt

See Demo Video Here:
https://www.youtube.com/watch?v=qLlhin-jfUE&index=3&list=PLvk-72jrjBFHtvl530CHKjxYeHcxEaV08
